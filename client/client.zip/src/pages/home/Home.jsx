import "./home.css"
import Header from "../../header/Header"

export default function Home() {
  return (
    <div className="home">
        <Header/>
    </div>
  )
}
