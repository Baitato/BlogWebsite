import "./blogs.css"
import Post from "../../post/Post.jsx"

const Blogs = () => {
  return (
    <div>
        <div className="container">
            <Post/>
        </div>
    </div>
  )
}

export default Blogs